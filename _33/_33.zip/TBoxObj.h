#pragma once
#include "xObject.h"
class TBoxObj : public xObject
{
public:
	virtual void	CreateVertexData();
	virtual void	CreateIndexData();
};

